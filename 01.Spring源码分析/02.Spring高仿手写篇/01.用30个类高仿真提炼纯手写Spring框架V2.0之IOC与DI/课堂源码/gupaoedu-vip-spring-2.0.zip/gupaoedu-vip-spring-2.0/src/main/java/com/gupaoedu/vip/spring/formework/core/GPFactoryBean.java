package com.gupaoedu.vip.spring.formework.core;

/**
 * Created by Tom.
 */
public interface GPFactoryBean {
}
